#ifndef MINECRAFT_OIT_DEPTH_BOUNDS_GLSL
#define MINECRAFT_OIT_DEPTH_BOUNDS_GLSL

layout(location = 0) out vec4 fragColor;

void calculateDepthBounds(float fragmentDeviceDepth, float alpha) {
    float fragmentLinearDepth = deviceToLinearDepth(fragmentDeviceDepth);
    float opaqueFragmentDeviceDepth = alpha > OIT_FULLY_OPAQUE_ALPHA ? fragmentDeviceDepth : 0.0;
    fragColor = vec4(-fragmentLinearDepth, fragmentLinearDepth, fragmentDeviceDepth, opaqueFragmentDeviceDepth);
}

#endif
