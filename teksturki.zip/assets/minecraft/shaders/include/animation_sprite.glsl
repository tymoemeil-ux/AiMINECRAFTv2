#ifndef MINECRAFT_ANIMATION_SPRITE_GLSL
#define MINECRAFT_ANIMATION_SPRITE_GLSL

layout(std140) uniform SpriteAnimationInfo {
    mat4 ProjectionMatrix;
    mat4 SpriteMatrix;
    float UPadding;
    float VPadding;
    int MipMapLevel;
};

#endif
